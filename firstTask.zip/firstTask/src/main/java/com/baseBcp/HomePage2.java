package com.baseBcp;

import static org.testng.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage2 {
	WebDriver driver;
	@FindBy(css = "#gh-ac")
	WebElement SearchForProductInput;
	@FindBy(css = "#gh-btn")
	WebElement SearchButton;

	public HomePage2(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	  public void veryfyUrl() {
      String correctUrl = "https://www.888.com/";
      System.out.println("Url is: "+driver.getCurrentUrl());
	  assertEquals(correctUrl, driver.getCurrentUrl()); }
	 

	public List<WebElement> getPriceObjects() {
		List<WebElement> AllSearchResults = driver.findElements(By.className("s-item__price"));
		return AllSearchResults;
	}

	public float[] listOfPrices(List<WebElement> listOfPricesFromFourth) {
		//First 3 digits are "ILS " and must be removed
		float[] listOfPrices=new float[listOfPricesFromFourth.size()-1];
		for (int i = 1; i < listOfPricesFromFourth.size(); i++) {
			//First element in ebay always empty so the method fills array from second element
			String strFromWebElem = listOfPricesFromFourth.get(i).getText();
			strFromWebElem=strFromWebElem.replaceAll(",", "");
			if (strFromWebElem.length() > 4) {
				listOfPrices[i-1] = Float.parseFloat(strFromWebElem.substring(4));
			}
		}

		return listOfPrices;
	}

	//move to "utils" class
	public float[] sortArray(float[] inputArray){
		float[] sortedArray= inputArray;
		Arrays.sort(sortedArray);
		System.out.println("minimum price is: "+sortedArray[0]);
		System.out.println("maximum price is: "+sortedArray[sortedArray.length-1]);
		return sortedArray;	
	}
	
	public float[] minimumAndMaximumPricesInPage(){
		float[] minMaxPrices=new float[2];
		float[] allPrices=sortArray(listOfPrices(getPriceObjects()));
		minMaxPrices[0]=allPrices[0];
		minMaxPrices[1]=allPrices[allPrices.length-1];
		 return	minMaxPrices;
	}

}
