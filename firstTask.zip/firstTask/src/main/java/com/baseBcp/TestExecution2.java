package com.baseBcp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.firstTask.HomePage;

public class TestExecution2 {
/*
	static WebDriver driver;
	HomePage objBrowserStackHomePage;

	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\1805d\\OneDrive\\Documents\\My_files\\Java\\Automation\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.get("https://www.888.com/");
	}

	@Test(priority = 1)
	public void navigate_to_homepage() {
		objBrowserStackHomePage = new HomePage(driver);
		objBrowserStackHomePage.veryfyUrl();
	}

	@Test(priority = 2)
	public void getMinimumAndMaksimumPriceOfWatches() {

		objBrowserStackHomePage.SearchForProductInput.sendKeys("watches seiko 5 mechanical vintage for men perfect condition");
		objBrowserStackHomePage.SearchButton.click();
		objBrowserStackHomePage.minimumAndMaximumPricesInPage();
	}
    @AfterClass
    public static void tearDownClass() {	
        driver.close();
    }
    */
}
