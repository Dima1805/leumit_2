package com.firstTask;

import static org.testng.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import infra.TextEditors;
import infra.languageDetection;

public class HomePage {
	WebDriver driver;
	@FindBy(xpath = "//div[@class='lang-bttn header-only-mobile']")
	WebElement langugesButton;	
	
	@FindBy(xpath = "//div[@class='lang-switch-dropdown header-only-mobile']//ul[@class='languagesList']/li[@class='languageLink']/a")
	List<WebElement> listOfLanguages;
	

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	  public void veryfyUrl(String correctUrl) {
      System.out.println("Url is: "+driver.getCurrentUrl());
	  assertEquals(correctUrl, driver.getCurrentUrl()); }
	 

	public List<WebElement> printListOfLanguages() {
//		List<WebElement> listOfLanguages = driver.findElements(By.xpath("//div[@class='lang-switch-dropdown header-only-mobile']//ul[@class='languagesList']/li[@class='languageLink']/a"));
		int i=0;
		for(WebElement ll:listOfLanguages) {
			i++;
			System.out.println(i+" language is "+ll.getAttribute("text"));
		}
		return listOfLanguages;
	}
	
	  public void veryfyList() {
		  printListOfLanguages();
			for(int k=0;k<listOfLanguages.size();k++) {				
				String href=(listOfLanguages.get(k)).getAttribute("href");
						//getAttribute("href");
				String laguage=TextEditors.getSegmentSubstring(href,"://",".888");
				System.out.println(k+" href is "+href+" lang is "+laguage);
				driver.get(href);
				veryfyLanguage(laguage);			
			}
	  }
	  
	  public String currentLanguge() {
		WebElement currentLanguge=driver.findElement(By.xpath("//div[@class='lang-bttn header-only-mobile']/span[@class='current-language']"));		
		return currentLanguge.getText() ;
	  }
	  
	  public void veryfyLanguage(String correctLanguage) {
	  String currentLanguage=currentLanguge();
	  currentLanguage=currentLanguage.toLowerCase();
	  System.out.println(correctLanguage+" correctLanguage");
	  System.out.println(currentLanguage+" correctLanguage");
	  System.out.println(currentLanguage.equals("www")+" eq www currentLanguage");
	  System.out.println(currentLanguage=="www"+" == www currentLanguage");
	  System.out.println(correctLanguage.equals("www")+" eq www correctLanguage");
	  System.out.println(correctLanguage=="www"+" == www correctLanguage");
	  if(correctLanguage.equals("www")) {
		  correctLanguage="en";
	  }
	  assertEquals(currentLanguage,correctLanguage );
	  }
}	
	
