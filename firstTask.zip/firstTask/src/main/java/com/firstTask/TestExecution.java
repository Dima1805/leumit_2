package com.firstTask;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestExecution {

	static WebDriver driver;
	HomePage objBrowserStackHomePage;

	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\1805d\\OneDrive\\Documents\\My_files\\Java\\Automation\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.get("https://www.888.com/");
		WebDriverWait wait=new WebDriverWait(driver, 30);
		//Close alert
		WebElement alert=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='onetrust-banner-sdk']")));
		alert.findElement(By.id("onetrust-accept-btn-handler")).click();
		
	}

	@Test(priority = 1)
	public void navigate_to_homepage() {
		objBrowserStackHomePage = new HomePage(driver);
		objBrowserStackHomePage.veryfyUrl("https://www.888.com/");
	}

	@Test(priority = 3)
	public void getListOfLaguges() {
		objBrowserStackHomePage.veryfyList();
		/*
		objBrowserStackHomePage.langugesButton.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
*/
	}
	
	@Test(priority = 2)
	public void checkLanguages() {
		objBrowserStackHomePage.veryfyLanguage("en");
		
	}
	
    @AfterClass
    public static void tearDownClass() {	
        driver.close();
    }
}
