package infra;

public class Test {

	public static void main(String[] args) {
		
		System.out.println(TextEditors.getSegmentByRegex("test string (67)","(",")"));
		System.out.println(TextEditors.getSegmentSubstring("test string (67)","(",")"));
		System.out.println(TextEditors.getSegmentByIndexes("test string (67)","(",")"));
		//System.out.println(TextEditors.getSegmentAnotherRegex("test string (67)","(",")"));
	}

}
