package infra;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class TextEditors {
	//good
	public static String getSegmentByIndexes(String input,String from, String until) {
		String result = input.substring(input.indexOf(from) , input.indexOf(until)+ 1);
		return result;
		}
	//problem
	public static String getSegmentSubstring(String input,String from, String until) {
		String result =StringUtils.substringBetween(input, from, until);
		
		return result;		
	}
	//good
	public static String getSegmentByRegex(String input, String startsFrom, String until) {
	    String escapedStartsFrom = Pattern.quote(startsFrom);
	    String escapedUntil = Pattern.quote(until);
	    String pattern = escapedStartsFrom + "\\w*" + escapedUntil;
	    Pattern regex = Pattern.compile(pattern);
	    Matcher matcher = regex.matcher(input);
	    
	    if (matcher.find()) {
	        return matcher.group();
	    } else {
	        return null;
	    }
	}

	
	
}
