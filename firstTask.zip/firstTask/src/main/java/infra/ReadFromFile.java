package infra;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFromFile {
	
	 //V zavisimosti ot sistemy raznue separatoru
	static String separator=File.separator;
    static String path="‪C:"+separator+"Users"+separator+"1805d"+separator+"OneDrive"+separator+"Documents"+separator+"testDima.txt";
	   //static String path="‪C:\\Users\\1805d\\OneDrive\\Documents\\testDima.txt";
	static File txtFile=new File (path);
    //‪C:\Users\1805d\OneDrive\Documents\123.txt
	//C:\Users\1805d\OneDrive\Documents\123.txt
	//base/src/main/123.txt
	public static void main(String[] args) throws FileNotFoundException {
		Scanner dimascanner=new Scanner(txtFile);
		while(dimascanner.hasNextLine()){
			System.out.println(dimascanner.nextLine());
			}
		dimascanner.close();
	}
}
