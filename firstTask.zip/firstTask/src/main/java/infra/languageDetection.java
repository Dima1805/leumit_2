package infra;

import com.google.cloud.translate.Translate;
import com.google.cloud.translate.TranslateOptions;

import org.openqa.selenium.WebDriver;

import com.google.cloud.translate.Detection;

public class languageDetection {
	//can't use it. I need a key. So I'll use wrong option
	public static String languageOfWebPage(WebDriver driver) {
	
    // Get the website's page source
    String allPageSource = driver.getPageSource();

    // Use Google Cloud's Language Detection API to detect the spoken language
    String pageSource=allPageSource.substring(1, 150000);
    
    // Use Google Cloud's Language Detection API to detect the spoken language
    TranslateOptions options = TranslateOptions.newBuilder()
        .setApiKey("my api key")
        .build();
    Translate translate = options.getService();
    Detection detection = translate.detect(pageSource);
    String language = detection.getLanguage();
    
    // Print the detected language
    System.out.println("The spoken language of the website is: " + language);
	return language;
	}
	
	
	

}
