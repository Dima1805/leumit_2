package com.secondTaskTest;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import infra.CsvToDictionary;


public class TestExecution {

	static WebDriver driver;
	HomePage objBrowserStackHomePage;

	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\1805d\\OneDrive\\Documents\\My_files\\Java\\Automation\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.get("http://www.w3schools.com/html/html_tables.asp");
		String csvFile = "C:\\Users\\1805d\\OneDrive\\Documents\\test.csv";
		String delimiter = ",";
		CsvToDictionary.loadCsvFile(csvFile, delimiter);
		CsvToDictionary.addKeyValuePair("getDataFromTable_TakeFromColumn", "0");
		CsvToDictionary.addKeyValuePair("getDataFromTable_ValueToFind", "Centro comercial Moctezuma");
		CsvToDictionary.addKeyValuePair("getDataFromTable_ReturnDataFromColumn", "2");
		CsvToDictionary.addKeyValuePair("verifyTableCellText_Expected", "Mexico");
		CsvToDictionary.addKeyValuePair("getDataByColumnName_lookup", "Company");
		CsvToDictionary.addKeyValuePair("getDataByColumnName_return", "Country");
	}

	@Test(priority = 1)
	public void navigate_to_homepage() {
		objBrowserStackHomePage = new HomePage(driver);
		objBrowserStackHomePage.veryfyUrl();
	}

	@Test(priority = 2)
	public void getDataFromTable() {
		System.out.print("relevant cell in table contains "+objBrowserStackHomePage.getTableCellT(
				CsvToDictionary.getValueForKey("getDataFromTable_TakeFromColumn"),
				CsvToDictionary.getValueForKey("getDataFromTable_ValueToFind"),
				CsvToDictionary.getValueForKey("getDataFromTable_ReturnDataFromColumn"))+" ");
	}
	
	@Test(priority = 3)
	public void verifyTableCellText() {
		boolean actualResult=objBrowserStackHomePage.verifyTableCellText(
				CsvToDictionary.getValueForKey("getDataFromTable_TakeFromColumn"),
				CsvToDictionary.getValueForKey("getDataFromTable_ValueToFind"),
				CsvToDictionary.getValueForKey("getDataFromTable_ReturnDataFromColumn"),
				CsvToDictionary.getValueForKey("verifyTableCellText_Expected"));
		Assert.assertEquals(actualResult, true, "Actual text is not equal to expected text.");
		
	}
	
	@Test(priority = 4)
	public void getDataFromTableByXpath() {
		System.out.print("relevant cell in table contains "+objBrowserStackHomePage.getTableCellTextByXpath(
				CsvToDictionary.getValueForKey("getDataFromTable_TakeFromColumn"),
				CsvToDictionary.getValueForKey("getDataFromTable_ValueToFind"),
				CsvToDictionary.getValueForKey("getDataFromTable_ReturnDataFromColumn"))+" ");
	}
	
	@Test(priority = 5)
	public void getDataByColumnName() {
		//same as getDataFromTable(), but working with names of columns
		System.out.print("relevant cell in table contains "+objBrowserStackHomePage.getTableCellTextByColumnName(
				CsvToDictionary.getValueForKey("getDataByColumnName_lookup"),
				CsvToDictionary.getValueForKey("getDataFromTable_ValueToFind"),
				CsvToDictionary.getValueForKey("getDataByColumnName_return"))+" ");
	}
	
    @AfterClass
    public static void tearDownClass() {	
        driver.close();
    }
}
