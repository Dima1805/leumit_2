package com.secondTaskTest;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class HomePage {
	WebDriver driver;
	@FindBy(id = "customers")
	WebElement customersTable;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	  public void veryfyUrl() {
      String correctUrl = "https://www.w3schools.com/html/html_tables.asp";
      System.out.println("Url is: "+driver.getCurrentUrl());
	  assertEquals(correctUrl, driver.getCurrentUrl()); }
	 

	    public String getTableCellT(String searchColumn, String searchText, String returnColumnText) {
	    	int intSearchColumn=Integer.valueOf(searchColumn);
	    	int intReturnColumnText=Integer.valueOf(returnColumnText);
	        return TableHelper.getTableCellText(customersTable, intSearchColumn, searchText, intReturnColumnText);
	    }
	    
	    public boolean verifyTableCellText(String searchColumn, String searchText, String returnColumnText,String expectedText) {
	    	int intSearchColumn=Integer.valueOf(searchColumn);
	    	int intReturnColumnText=Integer.valueOf(returnColumnText);
	        return TableHelper.verifyTableCellText(customersTable, intSearchColumn, searchText, intReturnColumnText,expectedText);
	    }
	    
	    public String getTableCellTextByXpath(String searchColumn, String searchText, String returnColumnText) {
	    	int intSearchColumn=Integer.valueOf(searchColumn);
	    	int intReturnColumnText=Integer.valueOf(returnColumnText);
	        return TableHelper.getTableCellText(customersTable, intSearchColumn, searchText, intReturnColumnText);
	    }

	    public String getTableCellTextByColumnName(String lookupColumnName,String searchText,String resultColumn) {
	    	int searchColumnInt= TableHelper.getTableColumnIndex(customersTable, lookupColumnName);
	    	int resultColumnInt= TableHelper.getTableColumnIndex(customersTable, resultColumn);
	    	   return TableHelper.getTableCellText(customersTable,  searchColumnInt, searchText, resultColumnInt);
	    
	    }
	    
}
