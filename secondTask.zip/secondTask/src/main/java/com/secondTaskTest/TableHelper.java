package com.secondTaskTest;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

public class TableHelper {
    public static String getTableCellText(WebElement table, int searchColumn, String searchText, int returnColumnText) {
        String cellText = null;
        try {
            // Get all rows in the table
            List<WebElement> rows = table.findElements(By.tagName("tr"));
            for (WebElement row : rows) {
                // Get all cells in the row
                List<WebElement> cells = row.findElements(By.tagName("td"));
                // Check if the search text is in the specified column
                if (cells.size() > searchColumn && cells.get(searchColumn).getText().equals(searchText)) {
                    // Get the text from the specified return column
                    if (cells.size() > returnColumnText) {
                        cellText = cells.get(returnColumnText).getText();
                        break; // Stop searching
                    } else {
                        throw new IndexOutOfBoundsException("Return column index out of range.");
                    }
                }
            }
            if (cellText == null) {
                throw new NoSuchElementException("Search text not found in table.");
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return cellText;
    }
    
   	public static boolean verifyTableCellText(WebElement table, int searchColumn, String searchText, int returnColumnText, String expectedText) {
   		String actualResult=getTableCellText( table, searchColumn,searchText, returnColumnText);
   		if(expectedText.equals(actualResult)) {
   			return true;
   		}
   		return false;	
   	}
   	
    public static String getTableCellTextByXpath(WebElement table, int searchColumn, String searchText, int returnColumnText) {
        String cellText = null;
        try {
            // Find the cell using XPath
            String xpath = ".//tr[contains(td[" + (searchColumn + 1) + "], '" + searchText + "')]/td[" + (returnColumnText + 1) + "]";
            WebElement cell = table.findElement(By.xpath(xpath));
            cellText = cell.getText();
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return cellText;
    }
    
    //method returns column number by giving a name of column
    public static int getTableColumnIndex(WebElement table, String searchText) {
        int columnIndex = -1;
        try {
            // Get the header row of the table
            WebElement headerRow = table.findElement(By.tagName("thead")).findElement(By.tagName("tr"));
            // Get all cells in the header row
            List<WebElement> headerCells = headerRow.findElements(By.tagName("th"));
            // Search for the cell with the specified text
            for (int i = 0; i < headerCells.size(); i++) {
                WebElement cell = headerCells.get(i);
                if (cell.getText().equals(searchText)) {
                    columnIndex = i;
                    break; // Stop searching
                }
            }
            if (columnIndex == -1) {
                throw new NoSuchElementException("Column not found in table.");
            }
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return columnIndex;
    }
}

