package infra;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Dictionary;
import java.util.Hashtable;

import org.openqa.selenium.NoSuchElementException;

public class CsvToDictionary {

    private static Dictionary<String, String> dict = new Hashtable<>();

    public static void addKeyValuePair(String key, String value) {
        if (dict.get(key) != null) {
            System.out.println("Key " + key + " already exists in the dictionary.");
            return;
        }
        dict.put(key, value);
    }

    public static String getValueForKey(String key) {
    	String result="failedToGet";
    	result=dict.get(key);
    	if(result.equals("failedToGet")) {
    		throw new NoSuchElementException("Search text not found in table.");
    	}
    	return result;
        
    }

    public static void loadCsvFile(String csvFile, String delimiter) {
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                String[] data = line.split(delimiter);
                addKeyValuePair(data[0], data[1]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/*
    public static void main(String[] args) {
        String csvFile = "path/to/your/csv/file.csv";
        String delimiter = ",";
        loadCsvFile(csvFile, delimiter);
        System.out.println(getValueForKey("key1"));
    }
    */
}
