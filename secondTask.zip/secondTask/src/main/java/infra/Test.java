package infra;

import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		
	//	System.out.println(TextEditors.extractString("test string (67)","(",")"));
	//	System.out.println(TextEditors.getSegment("test string (67)","(",")"));
	//	System.out.println(TextEditors.getSegmentByIndexes("test string (67)","(",")"));
		//String[] values = {"value1", "2", "value3"};
		//String[] values1 = {"0", "Centro comercial Moctezuma", "2"};
		//CsvToDictionaryComplicated.addKeyValuePair("fgh", values);
		//CsvToDictionaryComplicated.addKeyValuePair("fgh", values);
		//CsvToDictionaryComplicated.addKeyValuePair("getDataFromTable", values1);

		
			CsvToDictionary.loadCsvFile("C:\\Users\\1805d\\OneDrive\\Documents\\CSVDemo.csv", ",");
			CsvToDictionary.addKeyValuePair("value1", "2");
			CsvToDictionary.addKeyValuePair("value1", "2");
			CsvToDictionary.addKeyValuePair("value2", "montana");
			System.out.println(CsvToDictionary.getValueForKey("value1"));
			System.out.println(CsvToDictionary.getValueForKey("value2"));
//		System.out.println(CsvToDictionary.getValues("asd"));
//		System.out.println(values[2]);
//		System.out.println((CsvToDictionaryComplicated.getValues("fgh").get(2)));
//		System.out.println((CsvToDictionaryComplicated.getValues("getDataFromTable").get(0)));
//		CsvToDictionary.convertArrayListToMixedArray(CsvToDictionary.getValues("getDataFromTable"));
//		System.out.println((int)CsvToDictionary.MixedArrayForInputs[1]+1);
			System.out.println(Integer.valueOf("searchColumn"));

	}

}
